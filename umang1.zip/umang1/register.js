const mongoose = require("mongoose"); 

const empSchema = new mongoose.Schema({
    firstname:{String,required:true},
    lastname:{String,required:true}
})

const Register = new mongoose.model("index",empSchema);

module.export = Register; 

