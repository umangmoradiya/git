const express = require("express");
const app = express();
const Register = require("./register");
// const bodyparser = require("body-parser"); 

app.use(express.json());

mongoose.connect("mongodb://localhost:27017/index", {useNewUrlparser:true,useUnifiedTopology:true});


app.get("/form",(res,req)=>{
    res.sendfile(__dirname + "/1.html")
});
 app.get("/register",(req,res)=>{
     res.render("register");
 })

 app.post("/register", async(req,res)=>{
     try{
        console.log(req.body.firstname); 
     }
     catch(error){

     }
    
})


app.listen(5000,()=>{
    console.log("port no is 5000");
});