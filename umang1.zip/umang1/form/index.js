const express = require("express");
const app = express();
const bodyparser = require("body-parser");
const encoder = bodyparser.urlencoded();


const mysql = require("my-sql");
const res = require("express/lib/response");
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password:'',
    database: 'umang',
    connectionLimit: 10,
});
db.connect(err=>{
    if(err) throw err;
    console.log("database connected successfully....");
});

app.post("/form",encoder,(req,res)=>{
     var email = req.body.email;
     var phone_no = req.body.phone_no;
     db.query("select * from form where email = ? and phone_no = ?",[email,phone_no],(err,results,fislds)=>{
             if(results.length > 0){
                 console.log(' Account login Successfully.');
                 res.send(results);
                
             }else{
                res.send({
                    'message': 'User is already registerd'
                })
             }
             res.end();
     });
});




app.listen(5050,()=>{
    console.log("port no is 5050");
});